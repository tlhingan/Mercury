/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.thingmagic;

/**
 *
 * @author qvantel
 */
public class FeatureNotSupportedException extends ReaderException
{
    FeatureNotSupportedException(String message)
    {
        super(message);
    }
}

